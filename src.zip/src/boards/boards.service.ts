// src/boards/boards.service.ts
import { Injectable, NotFoundException, UnauthorizedException, BadRequestException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Board } from './schemas/board.schema';
import { CreateBoardDto } from './dto/create-board.dto';
import { UpdateBoardDto } from './dto/update-board.dto';
import { UpdateColumnOrderDto } from './dto/update-column-order.dto';
import { UsersService } from 'src/users/users.service';
import { User } from '../users/schemas/user.schema'; // 1. Importa el modelo de User


@Injectable()
export class BoardsService {
  constructor(
    @InjectModel(Board.name) private boardModel: Model<Board>,
    @InjectModel(User.name) private userModel: Model<User>,
    private usersService: UsersService
  ) { }

  async create(createBoardDto: CreateBoardDto, user: any): Promise<Board> {

    console.log(user)

    const newBoard = new this.boardModel({
      ...createBoardDto,
      owner: user._id, // El creador sigue siendo el dueño
      members: [user._id] // <<-- CAMBIO AQUÍ: Añade al creador como el primer miembro
    });
    return newBoard.save();
  }

  async findAllForUser(ownerId: string): Promise<Board[]> {
    return this.boardModel.find({ owner: ownerId }).exec();
  }

  async findOne(id: string, ownerId: string): Promise<Board> {
    const board = await this.boardModel.findById(id).exec();
    if (!board) {
      throw new NotFoundException(`Tablero con ID "${id}" no encontrado.`);
    }
    if (board.owner.toString() !== ownerId) {
      throw new UnauthorizedException('No tienes permiso para acceder a este tablero.');
    }
    return board;
  }

  async update(id: string, updateBoardDto: UpdateBoardDto, ownerId: string): Promise<Board> {
    await this.findOne(id, ownerId);

    const updatedBoard = await this.boardModel.findByIdAndUpdate(id, updateBoardDto, { new: true }).exec();

    if (!updatedBoard) {

      throw new NotFoundException(`Tablero con ID "${id}" no encontrado durante la actualización.`);
    }

    return updatedBoard;
  }

  async remove(id: string, ownerId: string): Promise<{ message: string }> {
    await this.findOne(id, ownerId);
    await this.boardModel.findByIdAndDelete(id).exec();
    return { message: `Tablero con ID "${id}" eliminado exitosamente.` };
  }



  async updateColumnOrder(id: string, updateColumnOrderDto: UpdateColumnOrderDto, ownerId: string): Promise<Board> {
    await this.findOne(id, ownerId);

    const { columnIds } = updateColumnOrderDto;

    const updatedBoard = await this.boardModel.findByIdAndUpdate(
      id,
      { columns: columnIds },
      { new: true }
    ).exec();

    if (!updatedBoard) {
      throw new NotFoundException(`Tablero con ID "${id}" no encontrado durante la actualización.`);
    }

    return updatedBoard;
  }


  async addMembers(boardId: string, emails: string[], userId: string): Promise<Board> {
   const board = await this.boardModel.findById(boardId);
    if (!board) {
        throw new NotFoundException(`Tablero con ID ${boardId} no fue encontrado.`);
    }
    if (board.owner.toString() !== userId && !board.members.map(m => m.toString()).includes(userId)) {
        throw new UnauthorizedException('No tienes permiso para invitar miembros a este tablero.');
    }

    const usersToAdd: User[] = await this.userModel.find({ email: { $in: emails } });
    
    if (usersToAdd.length !== emails.length) {
        throw new NotFoundException('Uno o más correos no fueron encontrados.');
    }

    const memberIds = board.members.map(id => id.toString());
    
    const newMemberIds = [];
    for (const user of usersToAdd) {
        // <<-- CAMBIO 1: Forzamos el tipo con "as any" para evitar el error de "unknown".
        if (!memberIds.includes((user._id as any).toString())) {
            // <<-- CAMBIO 2: Hacemos lo mismo aquí.
            newMemberIds.push(user._id as any);
        }
    }

    if (newMemberIds.length === 0) {
        throw new BadRequestException('Todos los usuarios seleccionados ya son miembros de este tablero.');
    }

    board.members.push(...newMemberIds);
    await board.save();
    
    return board.populate<{ members: User[] }>('members');
  }

}